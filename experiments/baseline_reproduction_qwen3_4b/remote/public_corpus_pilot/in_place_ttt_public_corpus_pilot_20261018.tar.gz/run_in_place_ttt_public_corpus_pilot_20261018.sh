#!/usr/bin/env bash
set -Eeuo pipefail

repo=/home/ctj/in_place_ttt_official_be232482
python_bin=/home/ctj/miniconda3/envs/cbf_ttt_verify_20260923/bin/python
inventory_root=/home/ctj/in_place_ttt_public_corpus_inventory_20261018
output_root=/home/ctj/in_place_ttt_public_corpus_pilot_20261018
run_root=/home/ctj/in_place_ttt_public_corpus_pilot_run_20261018

mkdir -p "$run_root"
status_file="$run_root/status.txt"

finish() {
  rc=$?
  trap - EXIT
  if [[ $rc -eq 0 ]]; then
    printf 'COMPLETED\nfinished_utc=%s\nexit_code=0\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "$status_file"
  else
    printf 'FAILED\nfinished_utc=%s\nexit_code=%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$rc" > "$status_file"
  fi
  exit "$rc"
}
trap finish EXIT

if [[ -e "$output_root" || -e "${output_root}.partial" ]]; then
  echo "Refusing to overwrite existing output: $output_root" >&2
  exit 17
fi

printf 'RUNNING\nstarted_utc=%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "$status_file"
cd "$repo"

sha256sum \
  IN_PLACE_TTT_BASELINE_PUBLIC_CORPUS_PLAN.md \
  scripts/build_in_place_ttt_public_corpus.py \
  scripts/audit_in_place_ttt_public_corpus.py \
  "$inventory_root/inventory.json" \
  "$inventory_root/independent_audit.json" \
  > "$run_root/input_sha256.txt"

nvidia-smi --query-gpu=index,name,memory.used,memory.total,utilization.gpu \
  --format=csv,noheader > "$run_root/gpu_before.csv"

/usr/bin/time -v "$python_bin" scripts/build_in_place_ttt_public_corpus.py \
  --inventory "$inventory_root/inventory.json" \
  --inventory-audit "$inventory_root/independent_audit.json" \
  --tokenizer /home/ctj/models/Qwen3-4B \
  --output-root "$output_root" \
  --profile pilot \
  --plan IN_PLACE_TTT_BASELINE_PUBLIC_CORPUS_PLAN.md \
  > "$run_root/build.log" 2> "$run_root/build.time_and_stderr.log"

/usr/bin/time -v "$python_bin" scripts/audit_in_place_ttt_public_corpus.py \
  --root "$output_root" \
  --inventory "$inventory_root/inventory.json" \
  --inventory-audit "$inventory_root/independent_audit.json" \
  --tokenizer /home/ctj/models/Qwen3-4B \
  --output "$output_root/independent_audit.json" \
  --plan IN_PLACE_TTT_BASELINE_PUBLIC_CORPUS_PLAN.md \
  --builder scripts/build_in_place_ttt_public_corpus.py \
  > "$run_root/audit.log" 2> "$run_root/audit.time_and_stderr.log"

nvidia-smi --query-gpu=index,name,memory.used,memory.total,utilization.gpu \
  --format=csv,noheader > "$run_root/gpu_after.csv"

find "$output_root" -type f -print0 | sort -z | xargs -0 sha256sum > "$run_root/output_sha256.txt"
